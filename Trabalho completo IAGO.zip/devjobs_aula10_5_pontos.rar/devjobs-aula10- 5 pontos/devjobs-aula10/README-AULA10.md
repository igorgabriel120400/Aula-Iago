# DevJobs - Aula 10

## Preparar o ambiente

Abra o terminal dentro da pasta `api` e execute:

```bash
npm install
```

Crie o arquivo `.env` copiando o `.env.example` e mantenha o segredo apenas no ambiente local.

Windows (PowerShell):
```powershell
Copy-Item .env.example .env
```

## Cadastrar empresa de teste

Ainda dentro de `api`, execute uma vez:

```bash
node src/database/seed.js
```

Empresa de teste:
- Email: `contato@technova.com`
- Senha: `123456`

O `seed.js` usa BCrypt para armazenar a senha com hash. Ele usa `INSERT OR IGNORE` para não duplicar a empresa, mas insere uma vaga de exemplo a cada execução.

## Iniciar a API

```bash
npm run dev
```

API: `http://localhost:3001`

## Testes

### 1. Login
`POST http://localhost:3001/api/auth/login`

```json
{
  "email": "contato@technova.com",
  "senha": "123456"
}
```

Copie o valor de `token` da resposta.

### 2. Tentar cadastrar sem token
`POST http://localhost:3001/api/vagas`

```json
{
  "titulo": "Teste",
  "tipo": "remoto",
  "tecnologias": "Node"
}
```

Esperado: HTTP 401, `Token não fornecido`.

### 3. Cadastrar com token
`POST http://localhost:3001/api/vagas`

Header:
`Authorization: Bearer COLE_SEU_TOKEN`

Body:
```json
{
  "titulo": "Vaga Autenticada",
  "tipo": "remoto",
  "tecnologias": "Node",
  "salario": "R$ 5.000",
  "cep": "01310100",
  "descricao": "Vaga de teste da Aula 10"
}
```

Esperado: HTTP 201 e os dados da vaga criada.

### 4. Consultar CEP
`GET http://localhost:3001/api/cep/01310100`

Esperado: dados de endereço de São Paulo/SP.

### 5. Excluir vaga
`DELETE http://localhost:3001/api/vagas/ID_DA_VAGA`

Header:
`Authorization: Bearer COLE_SEU_TOKEN`

Esperado: mensagem de sucesso. Uma empresa só consegue excluir vagas vinculadas ao próprio `empresa_id`.

## Observações
- `GET /api/vagas` continua público.
- `POST /api/vagas` e `DELETE /api/vagas/:id` exigem JWT.
- O token expira em 8 horas.
- A rota ViaCEP usa `fetch`, disponível nativamente no Node.js 18 ou superior.
- O arquivo `.env` já está previsto no `.gitignore`.
