
const API_URL = 'http://localhost:3001/api';
const TOKEN_KEY = 'devjobs-token';
const COMPANY_KEY = 'devjobs-company';

const jobsGrid = document.getElementById('jobs-grid');
const searchInput = document.getElementById('busca');
const countElement = document.getElementById('resultado-contagem');
const statusMessage = document.getElementById('status-message');
const loginModal = document.getElementById('login-modal');
const jobModal = document.getElementById('job-modal');

let vagas = [];
let token = localStorage.getItem(TOKEN_KEY);
let empresa = JSON.parse(localStorage.getItem(COMPANY_KEY) || 'null');

// ========================================
// FUNÇÕES AUXILIARES
// ========================================

function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char]);
}

function mostrarToast(message) {
  const toast = document.getElementById('toast');

  toast.textContent = message;
  toast.classList.add('show');

  window.setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

function abrirModal(modal) {
  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function fecharModal(modal) {
  modal.classList.add('hidden');

  if (
    loginModal.classList.contains('hidden') &&
    jobModal.classList.contains('hidden')
  ) {
    document.body.style.overflow = '';
  }
}

// ========================================
// EVENTOS DOS MODAIS
// ========================================

document.querySelectorAll('[data-close="login"]').forEach(el => {
  el.addEventListener('click', () => fecharModal(loginModal));
});

document.querySelectorAll('[data-close="job"]').forEach(el => {
  el.addEventListener('click', () => fecharModal(jobModal));
});

document.getElementById('login-open').addEventListener('click', () => {
  abrirModal(loginModal);
});

document.getElementById('banner-login').addEventListener('click', () => {
  if (token && empresa) {
    abrirModal(jobModal);
  } else {
    abrirModal(loginModal);
  }
});

document.getElementById('new-job-open').addEventListener('click', () => {
  abrirModal(jobModal);
});

// ========================================
// ÁREA DA EMPRESA
// ========================================

function atualizarAreaEmpresa() {
  const logado = Boolean(token && empresa);

  document.getElementById('login-open').classList.toggle('hidden', logado);
  document.getElementById('new-job-open').classList.toggle('hidden', !logado);
  document.getElementById('account-area').classList.toggle('hidden', !logado);

  document.getElementById('account-name').textContent = logado
    ? empresa.nome
    : '';

  renderizarVagas(filtrarVagas(searchInput.value));
}

// ========================================
// FUNÇÕES DAS VAGAS
// ========================================

function modalidadeLabel(tipo) {
  return ({
    remoto: 'Remoto',
    hibrido: 'Híbrido',
    presencial: 'Presencial'
  })[tipo] || tipo || 'Não informado';
}

function normalizarVaga(vaga) {
  const tecnologias = Array.isArray(vaga.tecnologias)
    ? vaga.tecnologias
    : String(vaga.tecnologias || '')
        .split(',')
        .map(item => item.trim())
        .filter(Boolean);

  const local = [vaga.cidade, vaga.estado]
    .filter(Boolean)
    .join(' / ');

  return {
    ...vaga,
    tecnologias,
    local: local || (
      vaga.tipo === 'remoto'
        ? 'Trabalho remoto'
        : 'Local não informado'
    )
  };
}

function criarCard(vagaOriginal) {
  const vaga = normalizarVaga(vagaOriginal);

  const card = document.createElement('article');
  card.className = 'job-card';

  const inicial = (vaga.empresa || 'E')
    .trim()
    .charAt(0)
    .toUpperCase();

  const techs = vaga.tecnologias
    .slice(0, 4)
    .map(tech => `<span class="tech-tag">${escapeHtml(tech)}</span>`)
    .join('');

  const podeExcluir = empresa &&
    Number(vaga.empresa_id) === Number(empresa.id);

  const data = vaga.created_at
    ? new Date(
        vaga.created_at.replace(' ', 'T') +
        (vaga.created_at.endsWith('Z') ? '' : 'Z')
      )
    : null;

  const dataLabel = data && !Number.isNaN(data.getTime())
    ? data.toLocaleDateString('pt-BR')
    : 'Oportunidade aberta';

  card.innerHTML = `
    <div class="job-card-top">
      <div class="job-company-mark">${escapeHtml(inicial)}</div>
      <span class="job-badge ${escapeHtml(vaga.tipo)}">
        ${escapeHtml(modalidadeLabel(vaga.tipo))}
      </span>
    </div>

    <div>
      <h3>${escapeHtml(vaga.titulo)}</h3>
      <p class="job-company">${escapeHtml(vaga.empresa || 'Empresa')}</p>
    </div>

    <div class="job-meta">
      <span>⌖ ${escapeHtml(vaga.local)}</span>
    </div>

    <p class="job-salary">
      ${escapeHtml(vaga.salario || 'Salário a combinar')}
    </p>

    <div class="tech-list">
      ${techs || '<span class="tech-tag">Tecnologias não informadas</span>'}
    </div>

    <div class="job-card-bottom">
      <span class="job-date">${escapeHtml(dataLabel)}</span>

      <div>
        <button class="text-button details-button" type="button">
          Detalhes ↗
        </button>

        ${podeExcluir
          ? '<button class="text-button delete-button" type="button">Excluir</button>'
          : ''}
      </div>
    </div>
  `;

  card.querySelector('.details-button').addEventListener('click', () => {
    const descricao = vaga.descricao ||
      'A empresa não informou uma descrição para esta oportunidade.';

    alert(
      `${vaga.titulo}\n` +
      `${vaga.empresa || ''}\n\n` +
      `${descricao}\n\n` +
      `Modalidade: ${modalidadeLabel(vaga.tipo)}\n` +
      `Local: ${vaga.local}\n` +
      `Salário: ${vaga.salario || 'A combinar'}\n` +
      `Tecnologias: ${vaga.tecnologias.join(', ')}`
    );
  });

  const deleteButton = card.querySelector('.delete-button');

  if (deleteButton) {
    deleteButton.addEventListener('click', async () => {
      if (!confirm(`Deseja excluir a vaga "${vaga.titulo}"?`)) {
        return;
      }

      try {
        const response = await fetch(`${API_URL}/vagas/${vaga.id}`, {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        const result = await response.json().catch(() => ({}));

        if (!response.ok) {
          throw new Error(
            result.erro || 'Não foi possível excluir a vaga.'
          );
        }

        mostrarToast('Vaga excluída.');
        await carregarVagas();

      } catch (error) {
        mostrarToast(error.message);
      }
    });
  }

  return card;
}

function renderizarVagas(lista) {
  jobsGrid.replaceChildren();

  countElement.textContent = lista.length;

  if (!lista.length) {
    const empty = document.createElement('div');

    empty.className = 'empty-state';

    empty.innerHTML =
      '<strong>Nenhuma oportunidade encontrada.</strong>' +
      'Experimente buscar por outro cargo ou tecnologia.';

    jobsGrid.appendChild(empty);
    return;
  }

  const fragment = document.createDocumentFragment();

  lista.forEach(vaga => {
    fragment.appendChild(criarCard(vaga));
  });

  jobsGrid.appendChild(fragment);
}

function filtrarVagas(termo) {
  const busca = termo.trim().toLocaleLowerCase('pt-BR');

  if (!busca) {
    return vagas;
  }

  return vagas.filter(vaga => {
    const item = normalizarVaga(vaga);

    const texto = [
      item.titulo,
      item.empresa,
      item.local,
      item.tipo,
      ...item.tecnologias
    ]
      .join(' ')
      .toLocaleLowerCase('pt-BR');

    return texto.includes(busca);
  });
}

// ========================================
// CARREGAMENTO DAS VAGAS
// ========================================

async function carregarVagas() {
  statusMessage.textContent = 'Carregando oportunidades...';
  statusMessage.classList.remove('error');

  try {
    const response = await fetch(`${API_URL}/vagas`);

    if (!response.ok) {
      throw new Error('A API não conseguiu carregar as vagas.');
    }

    vagas = await response.json();

    statusMessage.textContent = vagas.length
      ? ''
      : 'Ainda não há vagas cadastradas. Volte em breve!';

    renderizarVagas(filtrarVagas(searchInput.value));

  } catch (error) {
    statusMessage.textContent =
      'Não foi possível conectar à API. Confira se ela está rodando em http://localhost:3001.';

    statusMessage.classList.add('error');

    renderizarVagas([]);
  }
}

searchInput.addEventListener('input', () => {
  renderizarVagas(filtrarVagas(searchInput.value));
});

// ========================================
// INTEGRAÇÃO AUTOMÁTICA COM O VIACEP
// ========================================

const cepInput = document.getElementById('job-cep');
const cepStatus = document.getElementById('cep-status');

let ultimaConsultaCEP = '';
let consultaAtualCEP = 0;

cepInput.addEventListener('input', () => {
  let cep = cepInput.value.replace(/\D/g, '').slice(0, 8);

  // Formata o CEP: 00000-000
  if (cep.length > 5) {
    cep = cep.slice(0, 5) + '-' + cep.slice(5);
  }

  cepInput.value = cep;

  const numeros = cep.replace(/\D/g, '');

  // Se o usuário modificar o CEP, permite nova consulta
  if (numeros !== ultimaConsultaCEP) {
    ultimaConsultaCEP = '';
    consultaAtualCEP++;
  }

  cepStatus.textContent = '';
  cepStatus.style.color = '';

  if (numeros.length === 8) {
    consultarCEP(numeros);
  }
});

async function consultarCEP(cep) {
  if (cep === ultimaConsultaCEP) {
    return;
  }

  ultimaConsultaCEP = cep;

  const consulta = ++consultaAtualCEP;

  cepStatus.textContent = 'Consultando CEP...';
  cepStatus.style.color = '';

  try {
    const response = await fetch(`${API_URL}/cep/${cep}`);
    const dados = await response.json();

    // Ignora respostas de consultas anteriores
    if (consulta !== consultaAtualCEP) {
      return;
    }

    if (!response.ok) {
      throw new Error(
        dados.erro || 'Não foi possível consultar o CEP.'
      );
    }

    document.getElementById('job-city').value =
      dados.cidade || '';

    document.getElementById('job-state').value =
      dados.estado || '';

    document.getElementById('job-neighborhood').value =
      dados.bairro || '';

    document.getElementById('job-street').value =
      dados.logradouro || '';

    cepStatus.textContent = 'Endereço encontrado!';
    cepStatus.style.color = 'green';

  } catch (error) {
    if (consulta !== consultaAtualCEP) {
      return;
    }

    cepStatus.textContent = error.message;
    cepStatus.style.color = 'red';

    mostrarToast(error.message);
  }
}

// ========================================
// LOGIN DA EMPRESA
// ========================================

document.getElementById('login-form').addEventListener('submit', async event => {
  event.preventDefault();

  const button = document.getElementById('login-submit');
  const errorElement = document.getElementById('login-error');

  errorElement.textContent = '';

  button.disabled = true;
  button.textContent = 'Entrando...';

  try {
    const response = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',

      headers: {
        'Content-Type': 'application/json'
      },

      body: JSON.stringify({
        email: document.getElementById('login-email').value.trim(),
        senha: document.getElementById('login-password').value
      })
    });

    const result = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(result.erro || 'Não foi possível entrar.');
    }

    token = result.token;
    empresa = result.empresa;

    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(COMPANY_KEY, JSON.stringify(empresa));

    event.target.reset();

    fecharModal(loginModal);
    atualizarAreaEmpresa();

    mostrarToast(`Bem-vindo(a), ${empresa.nome}!`);

  } catch (error) {
    errorElement.textContent = error.message;

  } finally {
    button.disabled = false;
    button.textContent = 'Entrar na plataforma';
  }
});

// ========================================
// SAIR DA CONTA
// ========================================

document.getElementById('logout').addEventListener('click', () => {
  token = null;
  empresa = null;

  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(COMPANY_KEY);

  atualizarAreaEmpresa();

  mostrarToast('Você saiu da área da empresa.');
});

// ========================================
// PUBLICAÇÃO DE VAGAS
// ========================================

document.getElementById('job-form').addEventListener('submit', async event => {
  event.preventDefault();

  const button = document.getElementById('job-submit');
  const errorElement = document.getElementById('job-error');

  errorElement.textContent = '';

  button.disabled = true;
  button.textContent = 'Publicando...';

  const body = {
    titulo: document.getElementById('job-title').value.trim(),

    tipo: document.getElementById('job-type').value,

    tecnologias: document.getElementById('job-tech').value.trim(),

    salario: document.getElementById('job-salary').value.trim(),

    cep: document.getElementById('job-cep').value.trim(),

    cidade: document.getElementById('job-city').value.trim(),

    estado: document.getElementById('job-state').value
      .trim()
      .toUpperCase(),

    descricao: document.getElementById('job-description').value.trim()
  };

  try {
    const response = await fetch(`${API_URL}/vagas`, {
      method: 'POST',

      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },

      body: JSON.stringify(body)
    });

    const result = await response.json().catch(() => ({}));

    if (response.status === 401) {
      token = null;
      empresa = null;

      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(COMPANY_KEY);

      atualizarAreaEmpresa();

      fecharModal(jobModal);
      abrirModal(loginModal);

      throw new Error('Sua sessão expirou. Entre novamente.');
    }

    if (!response.ok) {
      throw new Error(
        result.erro || 'Não foi possível publicar a vaga.'
      );
    }

    event.target.reset();

    // Limpa o estado da consulta de CEP após publicação
    ultimaConsultaCEP = '';
    consultaAtualCEP++;

    cepStatus.textContent = '';

    fecharModal(jobModal);

    mostrarToast('Vaga publicada com sucesso!');

    await carregarVagas();

  } catch (error) {
    errorElement.textContent = error.message;

  } finally {
    button.disabled = false;
    button.textContent = 'Publicar oportunidade';
  }
});

// ========================================
// INICIALIZAÇÃO
// ========================================

atualizarAreaEmpresa();
carregarVagas();
