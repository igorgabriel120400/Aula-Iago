const { Router } = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database/db');

const router = Router();

router.post('/login', (req, res) => {
  const { email, senha } = req.body || {};

  if (!email || !senha) {
    return res.status(400).json({ erro: 'Email e senha são obrigatórios' });
  }

  const empresa = db.prepare(
    'SELECT id, nome, email, senha_hash FROM empresas WHERE email = ?'
  ).get(email);

  if (!empresa || !bcrypt.compareSync(senha, empresa.senha_hash)) {
    return res.status(401).json({ erro: 'Email ou senha inválidos' });
  }

  if (!process.env.JWT_SECRET) {
    return res.status(500).json({ erro: 'JWT_SECRET não configurado no .env' });
  }

  const token = jwt.sign(
    { id: empresa.id, nome: empresa.nome, email: empresa.email },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );

  return res.json({
    token,
    empresa: { id: empresa.id, nome: empresa.nome, email: empresa.email }
  });
});

module.exports = router;
