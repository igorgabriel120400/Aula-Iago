const { Router } = require('express');
const db = require('../database/db');
const auth = require('../middleware/auth.middleware');

const router = Router();

// Lista todas as vagas
router.get('/', (req, res) => {
  const vagas = db.prepare(`
    SELECT vagas.*, empresas.nome AS empresa
    FROM vagas
    JOIN empresas ON empresas.id = vagas.empresa_id
    ORDER BY vagas.created_at DESC
  `).all();

  res.json(vagas);
});

// Cria vaga: somente empresa autenticada
router.post('/', auth, (req, res) => {
  const { titulo, tipo, tecnologias, salario, cep, cidade, estado, descricao } = req.body || {};

  if (!titulo || !tipo || !tecnologias) {
    return res.status(400).json({
      erro: 'Os campos titulo, tipo e tecnologias são obrigatórios'
    });
  }

  if (!['remoto', 'presencial', 'hibrido'].includes(tipo)) {
    return res.status(400).json({
      erro: 'Tipo deve ser remoto, presencial ou hibrido'
    });
  }

  const resultado = db.prepare(`
    INSERT INTO vagas
      (titulo, empresa_id, tipo, tecnologias, salario, cep, cidade, estado, descricao)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    titulo,
    req.empresa.id,
    tipo,
    Array.isArray(tecnologias) ? tecnologias.join(', ') : tecnologias,
    salario || null,
    cep || null,
    cidade || null,
    estado || null,
    descricao || null
  );

  const vaga = db.prepare('SELECT * FROM vagas WHERE id = ?').get(resultado.lastInsertRowid);
  return res.status(201).json(vaga);
});

// Exclui somente vaga pertencente à empresa autenticada
router.delete('/:id', auth, (req, res) => {
  const resultado = db.prepare(
    'DELETE FROM vagas WHERE id = ? AND empresa_id = ?'
  ).run(req.params.id, req.empresa.id);

  if (resultado.changes === 0) {
    return res.status(404).json({ erro: 'Vaga não encontrada para esta empresa' });
  }

  return res.json({ mensagem: 'Vaga excluída com sucesso' });
});

module.exports = router;
