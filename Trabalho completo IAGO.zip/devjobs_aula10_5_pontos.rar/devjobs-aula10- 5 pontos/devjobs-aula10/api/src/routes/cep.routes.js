
const { Router } = require('express');

const router = Router();

// Consulta um CEP na API ViaCEP
router.get('/:cep', async (req, res) => {
  // Remove pontos, traços, espaços e outros caracteres
  const cep = req.params.cep.replace(/\D/g, '');

  // Valida se o CEP possui 8 dígitos
  if (cep.length !== 8) {
    return res.status(400).json({
      erro: 'CEP deve ter 8 dígitos'
    });
  }

  try {
    // Consulta o serviço ViaCEP
    const response = await fetch(
      `https://viacep.com.br/ws/${cep}/json/`
    );

    if (!response.ok) {
      return res.status(502).json({
        erro: 'Falha ao consultar ViaCEP'
      });
    }

    const data = await response.json();

    // Verifica se o CEP existe
    if (data.erro) {
      return res.status(404).json({
        erro: 'CEP não encontrado'
      });
    }

    // Retorna os dados do endereço
    return res.status(200).json({
      cep: data.cep,
      cidade: data.localidade,
      estado: data.uf,
      bairro: data.bairro,
      logradouro: data.logradouro,
      complemento: data.complemento
    });

  } catch (erro) {
    console.error('Erro ao consultar ViaCEP:', erro);

    return res.status(502).json({
      erro: 'Falha ao consultar ViaCEP'
    });
  }
});

module.exports = router;
