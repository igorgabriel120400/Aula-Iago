
require('dotenv').config();

const express = require('express');
const cors = require('cors');

require('./database/db');

const vagasRoutes = require('./routes/vagas.routes');
const authRoutes = require('./routes/auth.routes');
const cepRoutes = require('./routes/cep.routes');

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());

// Rota para verificar se a API está funcionando
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    projeto: 'DevJobs API',
    timestamp: new Date().toISOString()
  });
});

// Rotas da aplicação
app.use('/api/auth', authRoutes);
app.use('/api/vagas', vagasRoutes);
app.use('/api/cep', cepRoutes);

// Inicialização do servidor
app.listen(PORT, () => {
  console.log(`DevJobs API rodando em http://localhost:${PORT}`);
});
