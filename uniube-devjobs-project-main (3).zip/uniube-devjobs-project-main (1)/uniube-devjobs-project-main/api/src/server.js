const express = require('express');
const app = express();

// IMPORTANTE: Ativa o middleware para ler o corpo (body) das requisições em formato JSON
app.use(express.json());

// Importa o arquivo de rotas das vagas 
// (Ajuste o caminho se o seu arquivo de vagas tiver outro nome ou pasta)
const vagasRoutes = require('./routes/vagas'); 

// Vincula as rotas ao prefixo '/vagas'
app.use('/vagas', vagasRoutes);

// Define a porta em que a API vai rodar
const PORT = 3001;
app.listen(PORT, () => {
    console.log(`DevJobs API rodando em http://localhost:${PORT}`);
});
