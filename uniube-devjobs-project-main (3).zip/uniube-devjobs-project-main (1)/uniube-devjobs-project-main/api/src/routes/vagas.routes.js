const { Router } = require('express');
const router = Router();

const db = require('../database/db');

router.get('/', (req, res) => {
    try {
        const vagas = db.prepare(`
            SELECT v.*, e.nome AS empresa_nome
            from vagas v
            JOIN empresas e ON e.id = v.empresa_id
            ORDER BY v.created_at DESC
        `).all();

        res.json(vagas);
    } catch (error) {
        res.status(500).json({ erro: 'Erro ao buscar as vagas', detalhes: error.message });
    }
});

router.get('/:id', (req, res) => {
    const { id } = req.params;

    try {
        const vaga = db.prepare(`
            SELECT v.*, e.nome AS empresa_nome
            FROM vagas v
            JOIN empresas e ON e.id = v.empresa_id
            WHERE v.id = ?
        `).get(id);

        if (!vaga) {
            return res.status(404).json({ erro: 'Vaga não encontrada' });
        }

        res.json(vaga);
    } catch (error) {
        res.status(500).json({ erro: 'Erro ao buscar a vaga', detalhes: error.message });
    }
});

router.post('/', (req, res) => {
    const listaDeVagas = Array.isArray(req.body) ? req.body : [req.body];

    const insertStmt = db.prepare(`
        INSERT INTO vagas (titulo, empresa_id, tipo, tecnologias, salario, cep, cidade, estado, descricao)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const selectStmt = db.prepare('SELECT * FROM vagas WHERE id = ?');

    const salvarLoteDeVagas = db.transaction((vagas) => {
        const salvas = [];
        
        for (const vaga of vagas) {
            const { titulo, empresa_id, tipo, tecnologias, salario, cep, cidade, estado, descricao } = vaga;

            if (!titulo || !empresa_id || !tipo) {
                throw new Error('VALIDATION_ERROR: Campos obrigatórios ausentes.');
            }

            const result = insertStmt.run(
                titulo, 
                empresa_id, 
                tipo, 
                tecnologias || '', 
                salario || '', 
                cep || '', 
                cidade || '', 
                estado || '', 
                descricao || ''
            );

            const vagaSalva = selectStmt.get(result.lastInsertRowid);
            salvas.push(vagaSalva);
        }
        
        return salvas;
    });

    try {
        const resultadoFinal = salvarLoteDeVagas(listaDeVagas);
        res.status(201).json(resultadoFinal);
    } catch (error) {
        if (error.message.startsWith('VALIDATION_ERROR')) {
            return res.status(400).json({ erro: error.message });
        }
        
        res.status(500).json({ 
            erro: 'Erro ao processar e salvar o lote de vagas no banco', 
            detalhes: error.message 
        });
    }
});

router.put('/:id', (req, res) => {
    const { id } = req.params;
    const { titulo, empresa_id, tipo, tecnologias, salario, cep, cidade, estado, descricao } = req.body;

    if (!titulo || !empresa_id || !tipo) {
        return res.status(400).json({ erro: 'Campos obrigatórios: titulo, empresa_id e tipo' });
    }

    try {
        const result = db.prepare(`
            UPDATE vagas 
            SET titulo = ?, empresa_id = ?, tipo = ?, tecnologias = ?, salario = ?, cep = ?, cidade = ?, estado = ?, descricao = ?
            WHERE id = ?
        `).run(
            titulo, 
            empresa_id, 
            tipo, 
            tecnologias || '', 
            salario || '', 
            cep || '', 
            cidade || '', 
            estado || '', 
            descricao || '', 
            id
        );

        if (result.changes === 0) {
            return res.status(404).json({ erro: 'Vaga não encontrada para atualização' });
        }

        const vagaAtualizada = db.prepare(`
            SELECT v.*, e.nome AS empresa_nome
            FROM vagas v
            JOIN empresas e ON e.id = v.empresa_id
            WHERE v.id = ?
        `).get(id);

        res.json({ mensagem: 'Vaga atualizada com sucesso', vaga: vagaAtualizada });
    } catch (error) {
        if (error.message.includes('FOREIGN KEY')) {
            return res.status(400).json({ erro: 'Erro de integridade', detalhes: 'O empresa_id informado não existe.' });
        }
        res.status(500).json({ erro: 'Erro ao atualizar a vaga', detalhes: error.message });
    }
});

router.delete('/:id', (req, res) => {
    const { id } = req.params;

    try {
        const result = db.prepare('DELETE FROM vagas WHERE id = ?').run(id);

        if (result.changes === 0) {
            return res.status(404).json({ erro: 'Vaga não encontrada para exclusão' });
        }

        res.json({ mensagem: `Vaga com ID ${id} deletada com sucesso!` });
    } catch (error) {
        res.status(500).json({ erro: 'Erro ao deletar a vaga', detalhes: error.message });
    }
});

module.exports = router;
